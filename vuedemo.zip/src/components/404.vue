<template>
    <div>404</div>
</template>
<script>
    
</script>
<style>

</style>

