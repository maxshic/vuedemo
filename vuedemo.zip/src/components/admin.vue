<template>
    <div>admin</div>
</template>
<script>
    export default{
        name: 'admin',
        data(){
            return {

            }
        },
        created(){
            
        }
    }
</script>
