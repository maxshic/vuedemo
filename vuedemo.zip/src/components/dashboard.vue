<template>
    <div>
        dashboard
        <button @click='drawAuthPlus'>drawArr</button>
    </div>
</template>
<script>
    import { mapGetters } from 'vuex'
    export default{
        data(){
            return {

            }
        },
        created(){
            console.log(this.$store.state.auth)
        },
        computed: {
            ...mapGetters([
                //'drawArr',
                'drawAuthPlus',
                'drawAuthSub'
            ])
        }
    }
</script>
<style>

</style>

