<template>
    <div>visiter</div>
</template>
<script>
    export default{
        name: 'visiter',
        data(){
            return {

            }
        },
        created(){
            
        }
    }
</script>
