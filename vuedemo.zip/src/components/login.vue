<template>
    <div>
        <input type="text" v-model="val">
        <button @click="btn">submit</button>
    </div>    
</template>
<script>
export default {
    name: 'login',
    data(){
        return {
            val: ''
        }
    },
    beforeCreate(){
        console.log(location.href)
        history.pushState(null, null, document.URL);
        window.addEventListener('popstate', function () {
            history.pushState(null, null, document.URL);
        });
        //history.pushState(null ,null ,location.href)
    },
    created(){
        console.log(this.$store.state.auth)
    },
    methods: {
        btn(){
            if(this.val == 'admin'){
                this.$router.push({
                    path: '/dashboard',
                    query: {
                        auth: 'admin'
                    }
                })
            }
        }
    }
}
</script>
<style lang="scss">

</style>


